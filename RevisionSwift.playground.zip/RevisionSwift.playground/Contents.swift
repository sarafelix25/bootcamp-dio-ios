import UIKit

class Course {
    var title: String
    var description: String
    var competence: [String]

    init(title: String, description: String, competence: [String]) {
        self.title = title
        self.description = description
        self.competence = competence
    }
}

let courseSwift = Course(title: "Init with Swift", description: "Start your development in iOS applicatons using the Swift programming language", competence: ["Swift", "iOS", "XCode"])

print(courseSwift.title)
print(courseSwift.description)
print(courseSwift.competence[0])
